# JS Playground

Basic ES6 Concepts covering prepartion topics for interviews.
Play around some minor concepts for getting a better understanding of JS

Command for executing any file:
`node <path-to-file>/<file-name>`

Basic codes Courtesy: [Tejas Sabunkar](https://github.com/tsabunkar "Tejas Sabunkar") 😉