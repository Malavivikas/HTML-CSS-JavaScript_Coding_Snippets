# All Possible HTML/JS Service Call Methods

Methods Used:
- XMLHttpRequest
- Fetch
- Axios
- JQuery (AJAX)

Open Api Json website used is [jsonplaceholder.typicode.com](jsonplaceholder.typicode.com)