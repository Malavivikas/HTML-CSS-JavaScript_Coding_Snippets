// ! Declare but do not initialize a const
// const TODO; // ? Case 1: Throws an error as a cont variable is to be assigned a value while it is declared only
const TODO = "TODO"; // ? Case 2: Work perfectly

console.log(TODO); // ? output: TODO (Only comes for Case 2)