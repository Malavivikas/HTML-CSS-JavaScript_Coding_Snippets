
// ! Assign value to const
const SPECIES = "human";

// ! Attempt to reassign value
// SPECIES = "werewolf"; // ? Throws an error as reassigning values to a "const" variable isn't possible

console.log(SPECIES); // ? output: human