// If we async code , console.log() dont stop the exection it just keep on printing, but if we want
// to stop the execution then-
let a = 1;
let b = 2;

debugger; // will act as break point in the browser